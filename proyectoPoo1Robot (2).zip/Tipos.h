#ifndef PROYECTOFINAL_TIPOS_H
#define PROYECTOFINAL_TIPOS_H

#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <algorithm>
#include <map>
#include<queue>


using  namespace std;

typedef int entero;
typedef  string texto;


#endif //PROYECTOFINAL_TIPOS_H
